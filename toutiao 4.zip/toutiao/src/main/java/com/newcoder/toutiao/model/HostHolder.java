package com.newcoder.toutiao.model;

import org.springframework.stereotype.Component;

/**
 * Created by 000 on 2017/5/30.
 */
@Component
//该类表示当前的用户是谁,使用Spring依赖注入的方式
public class HostHolder {
    private static ThreadLocal<User> users=new ThreadLocal<User>();
    public User getUser(){
        return users.get();
    }
    public void setUser(User user){
       users.set(user);
    }
    public void clear(){
        users.remove();
    }
}
