package com.newcoder.toutiao.configuration;

import com.newcoder.toutiao.interceptor.LoginRequiredInterceptor;
import com.newcoder.toutiao.interceptor.PassportInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Created by 000 on 2017/5/30.
 */
@Component
public class ToutiaoWebConfiguration extends WebMvcConfigurerAdapter{
    @Autowired
    PassportInterceptor passportInterceptor;
    @Autowired
    LoginRequiredInterceptor loginRequiredInterceptor;
    @Override
    public void addInterceptors(InterceptorRegistry registry){
        registry.addInterceptor(passportInterceptor);//将自己写的拦截器注册进去
        registry.addInterceptor(loginRequiredInterceptor).addPathPatterns("/setting*");//只在处理/setting页面时，才会调用该拦截器
        super.addInterceptors(registry);
    }
}
