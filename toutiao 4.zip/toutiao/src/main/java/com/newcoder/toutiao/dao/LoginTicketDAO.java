package com.newcoder.toutiao.dao;

import com.newcoder.toutiao.model.LoginTicket;
import com.newcoder.toutiao.model.User;
import org.apache.ibatis.annotations.*;

/**
 * Created by 000 on 2017/5/30.
 */
@Mapper
public interface LoginTicketDAO {
    String TABLE_NAME="login_ticket";
    String INSERT_FIELDS= " user_id, expired, status, ticket ";//注意前后有空格,组合语句时会方便点
    String SELECT_FIELDS= " id, "+INSERT_FIELDS;
    @Insert({"insert into ", TABLE_NAME,"(",INSERT_FIELDS,
            ") values(#{userId},#{expired},#{status},#{ticket})"})
    int addTicket(LoginTicket ticket);

    @Select({"select ", SELECT_FIELDS, " from ",TABLE_NAME, " where ticket=#{ticket} "})
    LoginTicket selectByTicket(String ticket);

    @Update({"update ",TABLE_NAME," set status=#{status} where ticket=#{ticket}"})
    //有两个及以上的参数，使用下面的变量形式，即加上@Param
    void updateStatus(@Param("ticket")String ticket,@Param("status")int  status);

}
