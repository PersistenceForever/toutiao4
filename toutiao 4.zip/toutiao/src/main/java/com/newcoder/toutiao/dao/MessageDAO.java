package com.newcoder.toutiao.dao;

/**
 * Created by 000 on 2017/5/24.
 */
public interface MessageDAO {
}
