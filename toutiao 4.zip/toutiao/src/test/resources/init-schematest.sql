DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(64) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL,
  `ctreated_date` datetime NOT NULL,
  `news_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `message`;
CREATE TABLE `message`(
`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
`fromid` int(11) NOT NULL,
`toid` int(11) NOT NULL,
`content` varchar(256) NOT NULL DEFAULT '',
`conversation_id` int(11) NOT NULL,
`ctreated_date` datetime NOT NULL,
PRIMARY KEY (`id`),
)ENGINE=InooDB DEFAULT CHARSET=utf8;
